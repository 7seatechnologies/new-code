CodeIgniter AngularJS App
=========================

Sample App based on CodeIgniter and AngularJS.